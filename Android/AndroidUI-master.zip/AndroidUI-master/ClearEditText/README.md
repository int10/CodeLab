# Android EditText带清空按钮&动画
博客地址：http://blog.csdn.net/tyzlmjj/article/details/49156765

1. 单独EditText效果

![ClearEditTextA](https://github.com/tyzlmjj/IMAGES/blob/master/clearEditTextA.gif?raw=true)

2. 配合TextInputLayout使用的效果

![ClearEditTextB](https://github.com/tyzlmjj/IMAGES/blob/master/clearEditTextB.gif?raw=true)
