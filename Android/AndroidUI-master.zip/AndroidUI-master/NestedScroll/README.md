# Android  NestedScroll嵌套滚动

参考地址：

- http://www.jcodecraeer.com/a/anzhuokaifa/androidkaifa/2015/0603/2990.html
- http://www.jcodecraeer.com/a/anzhuokaifa/androidkaifa/2015/0822/3342.html

