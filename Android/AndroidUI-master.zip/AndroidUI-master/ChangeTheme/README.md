# ChangeTheme（夜间模式切换）
博客地址：http://blog.csdn.net/tyzlmjj/article/details/49255019
![ViewFlipper](https://github.com/tyzlmjj/IMAGES/blob/master/ChangeTheme.gif?raw=true)