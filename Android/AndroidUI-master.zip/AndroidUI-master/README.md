# AndroidUI

###博客地址：

1. http://blog.majiajie.me/

2. http://blog.csdn.net/tyzlmjj


-------


###GitHub下载单个文件夹教程：

使用 SVN

以我这个项目中的ViewFlipper为例子。

点进这个文件夹的上方网页地址是：https://github.com/tyzlmjj/AndroidUI/tree/master/ViewFlipper

将其中的`/tree/master/`改为`/trunk/`

然后输入命令行：

svn checkout https://github.com/tyzlmjj/AndroidUI/trunk/ViewFlipper

PS: 第一次使用的话, 可能会出现下面这个提示:

R)eject, accept (t)emporarily or accept (p)ermanently?

输入 P 就行了.
