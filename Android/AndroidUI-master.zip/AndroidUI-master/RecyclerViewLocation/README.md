# RecyclerView 定位
博客地址：http://blog.csdn.net/tyzlmjj/article/details/49227601
![RecyclerViewLocation](https://github.com/tyzlmjj/IMAGES/blob/master/RecyclerViewLocation.gif?raw=true)