# ClickEffect（各种点击效果总结）
博客地址：http://blog.csdn.net/tyzlmjj/article/details/50096777
![ClickEffect](https://github.com/tyzlmjj/IMAGES/blob/master/ClickEffect/ListB.gif?raw=true)

![ClickEffect](https://github.com/tyzlmjj/IMAGES/blob/master/ClickEffect/ImageViewClick.gif?raw=true)

![ClickEffect](https://github.com/tyzlmjj/IMAGES/blob/master/ClickEffect/StateListAnim.gif?raw=true)