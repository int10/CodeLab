package com.mjj.clickeffect;

import android.os.Bundle;

public class MaterialButtonActivity extends ABSActivity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_material_button);
	}
}
