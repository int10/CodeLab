# ViewFlipper
博客地址：http://blog.csdn.net/tyzlmjj/article/details/48576219
![ViewFlipper](https://github.com/tyzlmjj/IMAGES/blob/master/ViewFlipper.gif?raw=true)