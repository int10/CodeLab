android-gif-drawable-sample
===========================

Sample project for [android-gif-drawable](https://github.com/koral--/android-gif-drawable) library.

Used icons are either public domain, created by Dave Johnston or licensed under CC, GFDL available on
[Wikimedia Commons](https://commons.wikimedia.org)
