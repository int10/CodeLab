/**
 * Animated GIF library for Android. See {@link pl.droidsonroids.gif.GifDrawable}, {@link pl.droidsonroids.gif.GifTextureView}
 * and {@link pl.droidsonroids.gif.GifTexImage2D} classes for more details.
 */
package pl.droidsonroids.gif;