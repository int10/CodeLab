/**
 * Transformations performed before drawing GIF frames. See {@link pl.droidsonroids.gif.transforms.Transform}
 */
package pl.droidsonroids.gif.transforms;